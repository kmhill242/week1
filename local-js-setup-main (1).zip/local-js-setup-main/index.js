//**This is the entry point of you application(index.js) */

var cool = "cool";

console.log(cool);
